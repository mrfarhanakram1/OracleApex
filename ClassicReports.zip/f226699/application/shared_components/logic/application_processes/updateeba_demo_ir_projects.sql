prompt --application/shared_components/logic/application_processes/updateeba_demo_ir_projects
begin
--   Manifest
--     APPLICATION PROCESS: updateEBA_DEMO_IR_PROJECTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.2'
,p_default_workspace_id=>21982351062810350497
,p_default_application_id=>226699
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SKM5156'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(12904741479752232999)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'updateEBA_DEMO_IR_PROJECTS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  L_ID EBA_DEMO_IR_PROJECTS.ID%TYPE := APEX_APPLICATION.G_x01;',
'  L_COLUMN_NAME VARCHAR2(500) := APEX_APPLICATION.G_x02;',
'  L_COLUMN_VALUE VARCHAR2(4000) := APEX_APPLICATION.G_x03;',
'  L_DML VARCHAR2(4000);',
'BEGIN',
'  APEX_JSON.OPEN_OBJECT;',
'  L_DML:= ''UPDATE EBA_DEMO_IR_PROJECTS SET ''||L_COLUMN_NAME||''=''''''||L_COLUMN_VALUE||'''''' WHERE ID = ''''''||L_ID||'''''''';',
'  EXECUTE IMMEDIATE L_DML;',
'  ',
'  APEX_JSON.WRITE(''success'', true);',
'  APEX_JSON.WRITE(''message'', ''Value updated successfully!'');',
'  APEX_JSON.CLOSE_OBJECT;',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    APEX_JSON.WRITE(''success'', false);',
'    APEX_JSON.WRITE(''message'', SQLERRM);',
'    APEX_JSON.CLOSE_OBJECT;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>15544255394468
);
wwv_flow_imp.component_end;
end;
/
