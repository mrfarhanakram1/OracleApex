prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.2'
,p_default_workspace_id=>21982351062810350497
,p_default_application_id=>226699
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SKM5156'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Comments'
,p_alias=>'COMMENTS'
,p_step_title=>'Comments'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(59626244282144619368)
,p_name=>'Comments'
,p_region_name=>'Comments'
,p_template=>wwv_flow_imp.id(12697329433314565731)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat:t-Comments--iconsSquare'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROJECT,',
'       TASK_NAME COMMENT_TEXT,',
'       NULL ATTRIBUTE_1,',
'       NULL ATTRIBUTE_2,',
'       NULL ATTRIBUTE_3,',
'       NULL ATTRIBUTE_4,',
'       START_DATE COMMENT_DATE,',
'       END_DATE,',
'       STATUS,',
'       ASSIGNED_TO USER_NAME,',
'       COST,',
'       BUDGET,',
'       UPPER(SUBSTR(TASK_NAME,1,2)) USER_ICON,',
'       ''<div style="display:inline-block"><button class="t-Button t-Button--noLabel t-Button--icon t-Button--tiny t-Button--success" type="button" id="Button2" title="Button" aria-label="Button"><span class="t-Icon fa fa-check" aria-hidden="true"></s'
||'pan></button></div>'' ACTIONS',
'from EBA_DEMO_IR_PROJECTS'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(12697359034263565745)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12698604783668352482)
,p_query_column_id=>1
,p_column_alias=>'PROJECT'
,p_column_display_sequence=>10
,p_column_heading=>'Project'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703683743282580601)
,p_query_column_id=>2
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>100
,p_column_heading=>'Comment Text'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703684228708580606)
,p_query_column_id=>3
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>110
,p_column_heading=>'Attribute 1'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703684313942580607)
,p_query_column_id=>4
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>120
,p_column_heading=>'Attribute 2'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703684436120580608)
,p_query_column_id=>5
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>130
,p_column_heading=>'Attribute 3'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703684525672580609)
,p_query_column_id=>6
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>140
,p_column_heading=>'Attribute 4'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703684644541580610)
,p_query_column_id=>7
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>150
,p_column_heading=>'Comment Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12698605988021352484)
,p_query_column_id=>8
,p_column_alias=>'END_DATE'
,p_column_display_sequence=>40
,p_column_heading=>'End Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12698606370337352484)
,p_query_column_id=>9
,p_column_alias=>'STATUS'
,p_column_display_sequence=>50
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703684740496580611)
,p_query_column_id=>10
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>160
,p_column_heading=>'User Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12698607160982352485)
,p_query_column_id=>11
,p_column_alias=>'COST'
,p_column_display_sequence=>70
,p_column_heading=>'Cost'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12698607556634352485)
,p_query_column_id=>12
,p_column_alias=>'BUDGET'
,p_column_display_sequence=>80
,p_column_heading=>'Budget'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8833934004495973029)
,p_query_column_id=>13
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>90
,p_column_heading=>'User Icon'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703684858357580612)
,p_query_column_id=>14
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>170
,p_column_heading=>'Actions'
,p_heading_alignment=>'LEFT'
,p_display_as=>'RICH_TEXT'
,p_attribute_01=>'HTML'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp.component_end;
end;
/
