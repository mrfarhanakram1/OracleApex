prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.2'
,p_default_workspace_id=>21982351062810350497
,p_default_application_id=>226699
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SKM5156'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Timeline'
,p_alias=>'TIMELINE'
,p_step_title=>'Timeline'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(123121720052229687861)
,p_name=>'Timeline'
,p_region_name=>'Timeline'
,p_template=>wwv_flow_imp.id(12697329433314565731)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROJECT EVENT_DESC,',
'       TASK_NAME EVENT_TITLE,',
'       START_DATE EVENT_DATE,',
'       END_DATE,',
'       STATUS EVENT_TYPE ,',
'       ASSIGNED_TO USER_NAME,',
'       COST,',
'       BUDGET,',
'       UPPER(SUBSTR(ASSIGNED_TO,1,2)) USER_AVATAR',
'from EBA_DEMO_IR_PROJECTS'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(12697370487336565752)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703686387921580627)
,p_query_column_id=>1
,p_column_alias=>'EVENT_DESC'
,p_column_display_sequence=>120
,p_column_heading=>'Event Desc'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703686135786580625)
,p_query_column_id=>2
,p_column_alias=>'EVENT_TITLE'
,p_column_display_sequence=>100
,p_column_heading=>'Event Title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703686270135580626)
,p_query_column_id=>3
,p_column_alias=>'EVENT_DATE'
,p_column_display_sequence=>110
,p_column_heading=>'Event Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12699445283240625910)
,p_query_column_id=>4
,p_column_alias=>'END_DATE'
,p_column_display_sequence=>40
,p_column_heading=>'End Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703686041222580624)
,p_query_column_id=>5
,p_column_alias=>'EVENT_TYPE'
,p_column_display_sequence=>90
,p_column_heading=>'Event Type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703686429188580628)
,p_query_column_id=>6
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>130
,p_column_heading=>'User Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12699447260587625912)
,p_query_column_id=>7
,p_column_alias=>'COST'
,p_column_display_sequence=>70
,p_column_heading=>'Cost'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12699447693328625912)
,p_query_column_id=>8
,p_column_alias=>'BUDGET'
,p_column_display_sequence=>80
,p_column_heading=>'Budget'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12703686561327580629)
,p_query_column_id=>9
,p_column_alias=>'USER_AVATAR'
,p_column_display_sequence=>140
,p_column_heading=>'User Avatar'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
